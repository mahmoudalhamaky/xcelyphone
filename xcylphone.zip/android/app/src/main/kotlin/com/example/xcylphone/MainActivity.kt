package com.example.xcylphone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
